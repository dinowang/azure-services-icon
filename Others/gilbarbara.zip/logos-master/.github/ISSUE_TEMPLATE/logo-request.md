---
name: Logo request
about: Requests to add logos
title: "Add {NAME}"
labels: 'request'
assignees: gilbarbara

---

<!-- This is a curated collection of logos and I don't aim to add every single logo. -->
<!-- Just to be clear: Your request can be denied, be a good sport -->
<!-- Ask yourself: would you ever need to use this logo in a presentation or tool list? -->

<!-- Please do not flood the issues with several requests at once. -->

**Name with link**

**Description**

**Link to the vector file, preferably from an official source**
