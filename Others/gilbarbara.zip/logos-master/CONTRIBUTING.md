# Contributing

Since I optimize all the files manually I **won't** accept pull requests with new logos.  
Paste the URL for the file you wish to add or just upload it in the issue.  

This branch is auto-generated, so any changes to it will be erased.

I can't add every single logo to this repo since it would just make it bloated. And there's already tons of websites like that...  
So when submitting a new logo please consider if people already recognize the logo.  
This excludes personal blogs, libraries and frameworks that people won't even know there's a logo and/or don't care about it.
